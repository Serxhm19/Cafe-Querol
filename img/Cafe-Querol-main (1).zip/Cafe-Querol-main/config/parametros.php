<?php

define("url", "http://workspace.com/Workspace/Cafe-Querol/");
define("action_default", "");
define("imgurl","img/products/");




?>